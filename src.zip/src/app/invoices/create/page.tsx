import React from 'react';
import InvoiceCreatePage from '@/react/invoices/create/pages/invoice-create-page';

const Page = () => {
  return <InvoiceCreatePage />;
};

export default Page;
