import InvoicesViewerPage from '@/react/invoices/viewer/pages/invoices-viewer-page';

export default function Page() {
  return <InvoicesViewerPage />;
}
