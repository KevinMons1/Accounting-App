import React from 'react';
import InvoicesTable from '@/react/invoices/viewer/components/invoices-table';

const InvoicesViewerPage = () => {
  return (
    <div>
      <InvoicesTable />
    </div>
  );
};

export default InvoicesViewerPage;
